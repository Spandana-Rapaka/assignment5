# David-chu-s-china-bistro-restaurant-website
This is the simple dynamic website developed under the guidance of coursera.org
